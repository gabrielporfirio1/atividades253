<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $banco = "empresa";

    $conexao = new mysqli($host,$user,$pass,$banco);

   /* if($conexao){
        echo "conectado";
    } */
?>